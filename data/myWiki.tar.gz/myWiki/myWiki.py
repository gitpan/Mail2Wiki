#!/usr/bin/env python   
#coding=utf8

import myMail
import sys

if __name__ == "__main__":
    mailServer = "mail.alibaba-inc.com"
    wikiServer = "http://dbtech.corp.taobao.com/nwiki/api.php"
    myMail = myMail.MyMail(mailServer, "askdba", "xtv08UIF", wikiServer, "askdba", "801120")
     
    mailNum, mailSize = myMail.getMailStat()
    if mailNum == 0:
        myMail.quit()
        sys.exit()
     
    for mailNo in range(mailNum): 
        mailMessage = myMail.getMessageFromString(mailNo) 
         
        mailFrom = myMail.getMailFrom(mailMessage)
        mailDate = myMail.getMailDate(mailMessage)
        mailSubject = myMail.getMailSubject(mailMessage, mailFrom)
        mailContent = myMail.getMailContent(mailMessage, mailSubject)
         
        print "\nSubject: %s, From: %s, Date: %s" % (mailSubject, mailFrom, mailDate)
        print "Content: \n%s\n" % (mailContent)
         
        myMail.doPostMail(mailSubject, mailContent, mailFrom, mailDate, mailNo)
        myMail.initProp()
         
    for mailNo in myMail.delList:
        myMail.dele(mailNo)
     
    myMail.quit()
