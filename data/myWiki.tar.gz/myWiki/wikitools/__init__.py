# -*- coding: utf-8 -*-
__all__ = ["wiki", "api", "page", "category", "user", "pagelist", "wikifile"]
from api import *
from wiki import *
from page import *
from user import *
from category import *
from wikifile import *
