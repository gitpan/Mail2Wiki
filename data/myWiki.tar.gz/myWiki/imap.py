# imap4.py   
#coding=utf8

import imaplib

myUser = 'askdba'
myPass = "xtv08UIF"
imap4 = imaplib.IMAP4_SSL('mail.alibaba-inc.com')   
ret = imap4.login(myUser, myPass)
print ret

result, message = imap4.select()
type, data = imap4.search(None, 'ALL')
numMailes =  data[0].split(" ")
for num in numMailes:
    print num
    if int(num) > 4:
        continue
     
    type, data = imap4.fetch(num, '(RFC822)')
    print type
    print data
     
#lines = p.retr(number)[1]           #下载邮件  
#msg = email.message_from_string("\n".join(lines)) 


"""
# 获取欢迎消息   
serverWelcome = emailServer.getwelcome()   
print serverWelcome   

# 获取一些统计信息   
emailMsgNum, emailSize = emailServer.stat()   
print 'email number is %d and size is %d' % (emailMsgNum, emailSize)   

# 遍历邮件，并打印出每封邮件的标题   
for i in range(emailMsgNum):   
    for piece in emailServer.retr(i+1)[1]:   
        if piece.startswith('Subject'):   
            print '\t' + piece   
            break   

emailServer.quit()
"""
