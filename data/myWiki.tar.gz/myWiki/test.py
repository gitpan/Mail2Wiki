#!/usr/bin/env python
# author: yekai gmtCreate: 2012-10-23 desc: Host grouping optimization
# coding = utf-8

from wikitools import *
import sys
import re

if __name__ == "__main__":
    reload(sys)
    sys.setdefaultencoding('utf8')
    print "now charset: %s!\n" % sys.getdefaultencoding()
      
    uuid = "A619d49c7377ecb9aa0c0acd43630411"
    print uuid[:16]
    strMsg = 'aaa<a href="http://beidou.corp.taobao.com/wiki/index.php/MyGuide" target="_blank">bbb</a>'
    pattern = re.compile(r'<a href="(.*?)"\s(.*?)>(.*?)</a>')
    match = pattern.findall(strMsg)
    if match:
        print match
    else:
        print "no match"
     
    match = pattern.search(strMsg)
    if match:
        print match.group()
    else:
        print "no match"
     
    """
    baseURL = "http://dbtech.corp.taobao.com/mwiki/api.php"
    wiki = wiki.Wiki(baseURL) 
    ret = wiki.login("yekai", "801120")
     
    params = {'action': 'query', 'list': 'allpages', 'aplimit': 10, 'apfrom': 'B', "apnamespace": "2"}
    request = api.APIRequest(wiki, params)
    result = request.query()
    print result['query']['allpages'][0]['title']
     
    page = page.Page(site = wiki, title = "test, this is a test", namespace = 2)
    resultt = page.edit(title='test, this is a test', text='test by yekai')
    print result 
    """
     
